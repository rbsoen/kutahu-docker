// UK lang variables

tinyMCELang['lang_insertdate_desc'] = 'Insert date';
tinyMCELang['lang_inserttime_desc'] = 'Insert time';
