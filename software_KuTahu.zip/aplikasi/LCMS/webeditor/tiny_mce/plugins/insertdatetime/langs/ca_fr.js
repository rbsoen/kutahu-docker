// CAN_FR lang variables

tinyMCELang['lang_insertdate_desc'] = 'Ins&egrave;rer la date';
tinyMCELang['lang_inserttime_desc'] = 'Ins&egrave;rer l\'heure';
