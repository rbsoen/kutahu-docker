// SE lang variables

tinyMCELang['lang_insertdate_desc'] = 'Klistra in datum';
tinyMCELang['lang_inserttime_desc'] = 'Klistra in tid';
