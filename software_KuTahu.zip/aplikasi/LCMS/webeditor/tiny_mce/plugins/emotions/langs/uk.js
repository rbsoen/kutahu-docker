// UK lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Insert emotion';
tinyMCELang['lang_emotions_desc'] = 'Emotions';

