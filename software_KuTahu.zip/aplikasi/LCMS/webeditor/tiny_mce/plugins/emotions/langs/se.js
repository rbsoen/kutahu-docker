// SE lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Klistain k�nnsla';
tinyMCELang['lang_emotions_desc'] = 'K�nnslor';
