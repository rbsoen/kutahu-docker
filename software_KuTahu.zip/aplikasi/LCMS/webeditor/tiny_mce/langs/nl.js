// NL lang variables thanks to "Meint Post"

tinyMCELang['lang_bold_desc'] = 'Vet';
tinyMCELang['lang_italic_desc'] = 'Schuin';
tinyMCELang['lang_underline_desc'] = 'Onderstrepen';
tinyMCELang['lang_striketrough_desc'] = 'Doorhalen';
tinyMCELang['lang_justifyleft_desc'] = 'Links uitlijnen';
tinyMCELang['lang_justifycenter_desc'] = 'Centreren';
tinyMCELang['lang_justifyright_desc'] = 'Rechts uitlijnen';
tinyMCELang['lang_justifyfull_desc'] = 'Volledig uitlijnen';
tinyMCELang['lang_bullist_desc'] = 'Ongeordende lijst';
tinyMCELang['lang_numlist_desc'] = 'Geordende lijst';
tinyMCELang['lang_outdent_desc'] = 'Uitspringen';
tinyMCELang['lang_indent_desc'] = 'Inspringen';
tinyMCELang['lang_undo_desc'] = 'Ongedaan maken';
tinyMCELang['lang_redo_desc'] = 'Opnieuw uitvoeren';
tinyMCELang['lang_link_desc'] = 'Link invoegen';
tinyMCELang['lang_unlink_desc'] = 'Link verwijderen';
tinyMCELang['lang_image_desc'] = 'Afbeelding invoegen';
tinyMCELang['lang_cleanup_desc'] = 'Slordige code verbeteren';
tinyMCELang['lang_focus_alert'] = 'Verplaats de focus naar de editor voor het uitvoeren van dit commado.';
tinyMCELang['lang_edit_confirm'] = 'Wilt u de WYSIWYG mode voor deze textarea gebruiken?';
tinyMCELang['lang_insert_link_title'] = 'Link invoegen/bewerken';
tinyMCELang['lang_insert'] = 'Invoegen';
tinyMCELang['lang_cancel'] = 'Afbreken';
tinyMCELang['lang_insert_link_url'] = 'URL link';
tinyMCELang['lang_insert_link_target'] = 'Bestemming';
tinyMCELang['lang_insert_link_target_same'] = 'Open link in hetzelfde venster';
tinyMCELang['lang_insert_link_target_blank'] = 'Open link in een nieuw venster';
tinyMCELang['lang_insert_image_title'] = 'Afbeelding invoegen/bewerken';
tinyMCELang['lang_insert_image_src'] = 'URL afbeelding';
tinyMCELang['lang_insert_image_alt'] = 'Beschrijving afbeelding';
tinyMCELang['lang_help_desc'] = 'Help';
tinyMCELang['lang_bold_img'] = "bold.gif";
tinyMCELang['lang_italic_img'] = "italic.gif";

