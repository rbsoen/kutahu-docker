// PL lang variables

tinyMCELang['lang_bold_desc'] = 'Pogrubienie';
tinyMCELang['lang_italic_desc'] = 'Pochylenie';
tinyMCELang['lang_underline_desc'] = 'Podkre�lenie';
tinyMCELang['lang_striketrough_desc'] = 'Przekre�lenie';
tinyMCELang['lang_justifyleft_desc'] = 'Wyr�wnaj do lewej';
tinyMCELang['lang_justifycenter_desc'] = 'Wy�rodkowanie';
tinyMCELang['lang_justifyright_desc'] = 'Wyr�wnaj do prawej';
tinyMCELang['lang_justifyfull_desc'] = 'Wyjustowanie';
tinyMCELang['lang_bullist_desc'] = 'Lista nieuporz�dkowana';
tinyMCELang['lang_numlist_desc'] = 'Lista uporz�dkowana';
tinyMCELang['lang_outdent_desc'] = 'Wysuni�cie';
tinyMCELang['lang_indent_desc'] = 'Wci�cie';
tinyMCELang['lang_undo_desc'] = 'Cofnij';
tinyMCELang['lang_redo_desc'] = 'Pon�w';
tinyMCELang['lang_link_desc'] = 'Wstaw ��cze';
tinyMCELang['lang_unlink_desc'] = 'Usu� ��cze';
tinyMCELang['lang_image_desc'] = 'Wstaw obrazek';
tinyMCELang['lang_cleanup_desc'] = 'Oczy�� kod';
tinyMCELang['lang_focus_alert'] = 'Pole edytora musi by� aktywne zanim ta funkcja zostanie u�yta.';
tinyMCELang['lang_edit_confirm'] = 'Czy chcesz u�y� trybu WYSIWYG dla tego pola tekstowego ?';
tinyMCELang['lang_insert_link_title'] = 'Wstaw/edtytuj ��cze';
tinyMCELang['lang_insert'] = 'Wstaw';
tinyMCELang['lang_cancel'] = 'Anuluj';
tinyMCELang['lang_insert_link_url'] = 'Adres URL';
tinyMCELang['lang_insert_link_target'] = 'Cel';
tinyMCELang['lang_insert_link_target_same'] = 'Otw�rze ��cze w tym samym oknie';
tinyMCELang['lang_insert_link_target_blank'] = 'Otw�rz ��cze w nowym oknie';
tinyMCELang['lang_insert_image_title'] = 'Wstaw/Edytuj zdj�cie';
tinyMCELang['lang_insert_image_src'] = 'Adres zdj�cia';
tinyMCELang['lang_insert_image_alt'] = 'Opis zdj�cia';
tinyMCELang['lang_help_desc'] = 'Pomoc';
tinyMCELang['lang_bold_img'] = "bold.gif";
tinyMCELang['lang_italic_img'] = "italic.gif";

