// HU lang variables
// Edited by 2XP (2xp@dino.hu)

tinyMCELang['lang_bold_desc'] = 'F&#233;lk&#246;v&#233;r';
tinyMCELang['lang_italic_desc'] = 'D&#245;lt';
tinyMCELang['lang_underline_desc'] = 'Al&#225;h&#250;zott';
tinyMCELang['lang_striketrough_desc'] = '&#193;th&#250;zott';
tinyMCELang['lang_justifyleft_desc'] = 'Balra igaz&#237;t&#225;s';
tinyMCELang['lang_justifycenter_desc'] = 'K&#246;z&#233;pre igaz&#237;t&#225;s';
tinyMCELang['lang_justifyright_desc'] = 'Jobbra igaz&#237;t&#225;s';
tinyMCELang['lang_justifyfull_desc'] = 'Sorkiz&#225;rt';
tinyMCELang['lang_bullist_desc'] = 'Felsorol&#225;s';
tinyMCELang['lang_numlist_desc'] = 'Sz&#225;mozott lista';
tinyMCELang['lang_outdent_desc'] = 'Beh&#250;z&#225;s balra';
tinyMCELang['lang_indent_desc'] = 'Beh&#250;z&#225;s jobbra';
tinyMCELang['lang_undo_desc'] = 'Visszavon&#225;s';
tinyMCELang['lang_redo_desc'] = 'Ism&#233;tl&#233;s';
tinyMCELang['lang_link_desc'] = 'Link felv&#233;tele';
tinyMCELang['lang_unlink_desc'] = 'Link t&#246;rl&#233;se';
tinyMCELang['lang_image_desc'] = 'K&#233;p beilleszt&#233;se';
tinyMCELang['lang_cleanup_desc'] = 'K&#243;d tiszt&#237;t&#225;sa';
tinyMCELang['lang_focus_alert'] = 'Miel\u00F5tt haszn\u00E1lja ezt a funkci\u00F3t, ki kell jel\u00F6lnie a szerkeszteni k\u00EDv\u00E1nt ter\u00FCletet.';
tinyMCELang['lang_edit_confirm'] = 'K\u00EDv\u00E1nja a WYSIWYG m\u00F3dot erre a sz\u00F6vegter\u00FCletre alkalmazni??';
tinyMCELang['lang_insert_link_title'] = 'Link beilleszt&#233;se/szerkeszt&#233;se';
tinyMCELang['lang_insert'] = 'Beilleszt&#233;s';
tinyMCELang['lang_cancel'] = 'M&#233;gsem';
tinyMCELang['lang_insert_link_url'] = 'Link URL';
tinyMCELang['lang_insert_link_target'] = 'C&#233;l';
tinyMCELang['lang_insert_link_target_same'] = 'Link megnyit&#225;sa azonos ablakban';
tinyMCELang['lang_insert_link_target_blank'] = 'Link megnyit&#225;sa &#250;j ablakban';
tinyMCELang['lang_insert_image_title'] = 'K&#233;p beilleszt&#233;se/szerkeszt&#233;se';
tinyMCELang['lang_insert_image_src'] = 'K&#233;p URL';
tinyMCELang['lang_insert_image_alt'] = 'K&#233;ple&#237;r&#225;s';
tinyMCELang['lang_help_desc'] = 'Seg&#237;t&#233;g';
tinyMCELang['lang_bold_img'] = 'bold.gif';
tinyMCELang['lang_italic_img'] = 'italic.gif';
