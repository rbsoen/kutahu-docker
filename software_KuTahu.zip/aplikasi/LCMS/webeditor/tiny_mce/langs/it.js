// Variabili lingua IT - fabrix.xm@lombardiacom.it

tinyMCELang['lang_bold_desc'] = 'Grassetto';
tinyMCELang['lang_italic_desc'] = 'Corsivo';
tinyMCELang['lang_underline_desc'] = 'Sottolineato';
tinyMCELang['lang_striketrough_desc'] = 'Barrato';
tinyMCELang['lang_justifyleft_desc'] = 'Allinea a sinistra';
tinyMCELang['lang_justifycenter_desc'] = 'Allinea centrato';
tinyMCELang['lang_justifyright_desc'] = 'Allinea a destra';
tinyMCELang['lang_justifyfull_desc'] = 'Giustifica';
tinyMCELang['lang_bullist_desc'] = 'Lista non ordinata';
tinyMCELang['lang_numlist_desc'] = 'Lista ordinata';
tinyMCELang['lang_outdent_desc'] = 'Rientra';
tinyMCELang['lang_indent_desc'] = 'Indenta';
tinyMCELang['lang_undo_desc'] = 'Annulla';
tinyMCELang['lang_redo_desc'] = 'Ripeti';
tinyMCELang['lang_link_desc'] = 'Inserisci link';
tinyMCELang['lang_unlink_desc'] = 'Elimina link';
tinyMCELang['lang_image_desc'] = 'Inserisci immagine';
tinyMCELang['lang_cleanup_desc'] = 'Pulisci il  codice';
tinyMCELang['lang_focus_alert'] = 'Una istanza dell\' editor deve essere selezionata prima di usare questo comando.';
tinyMCELang['lang_edit_confirm'] = 'Vuoi usare la modalit\u00E0 WYSIWYG per questa textarea?';
tinyMCELang['lang_insert_link_title'] = 'Inserisci/modifica link';
tinyMCELang['lang_insert'] = 'Inserisci';
tinyMCELang['lang_cancel'] = 'Cancella';
tinyMCELang['lang_insert_link_url'] = 'Link URL';
tinyMCELang['lang_insert_link_target'] = 'Target';
tinyMCELang['lang_insert_link_target_same'] = 'Apri il link nella stessa finestra';
tinyMCELang['lang_insert_link_target_blank'] = 'Apri il link in una nuova finestra';
tinyMCELang['lang_insert_image_title'] = 'Inserisci/modifica immagine';
tinyMCELang['lang_insert_image_src'] = 'URL immagine';
tinyMCELang['lang_insert_image_alt'] = 'Descrizione dell\'immagine';
tinyMCELang['lang_help_desc'] = 'Guida';
tinyMCELang['lang_bold_img'] = "bold.gif";
tinyMCELang['lang_italic_img'] = "italic.gif";

